<?php
class Karyawan extends \Phalcon\Mvc\Model
{
 public $nik; // field nik dalam tabel
 public $nama_lengkap;// field nama_lengkap
 public $alamat;// field nama_lengkap
}