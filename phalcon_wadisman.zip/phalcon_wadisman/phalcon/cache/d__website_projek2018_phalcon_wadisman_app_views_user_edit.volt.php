


 <br/>
 Hello codedoct!!!
 <br><br>
 <div class="row">
  <div class="col-md-12">
   <form method="POST">
    <div class="form-group">
     <label>Nama Lengkap</label>
     <input type="text" name="nama_lengkap" class="form-control" placeholder="Type your name" required value="<?= $user->nama_lengkap ?>">
    </div>
    
    <input type="submit" value="Edit"> <button type="button" onclick="window.location.href='../../user'">Cancel</button>
   </form>
  </div>
 </div>
